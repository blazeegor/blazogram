class BaseFilter:
    async def __check__(self, update) -> bool:
        pass