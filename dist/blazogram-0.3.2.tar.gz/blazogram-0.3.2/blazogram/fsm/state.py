class State:
    pass